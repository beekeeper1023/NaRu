# Linux 설치 가이드

Ubuntu 22.04 / Debian 12 / Fedora 38 기준으로 작성되었습니다.

## 사전 요건

```bash
# Python 버전 확인
python3 --version  # 3.9 이상 필요

# Claude Code 버전 확인
claude --version

# Git 확인
git --version
```

Python 3.9 미만이면:

```bash
# Ubuntu/Debian
sudo apt update && sudo apt install python3 python3-pip -y

# Fedora
sudo dnf install python3 python3-pip -y
```

---

## 1단계 — 저장소 클론

```bash
git clone https://github.com/{your-username}/naru.git ~/naru
cd ~/naru
```

---

## 2단계 — Atlassian API 토큰 발급

1. [id.atlassian.com/manage-profile/security/api-tokens](https://id.atlassian.com/manage-profile/security/api-tokens) 접속
2. **Create API token** → 이름 입력 → 생성
3. 토큰 값 복사

---

## 3단계 — 설정

### 방법 A: GUI (브라우저 있는 환경)

```bash
xdg-open tools/cag-settings.html
# 또는
firefox tools/cag-settings.html
```

settings.json 다운로드 후:
```bash
cp ~/Downloads/settings.json .claude/settings.json
```

### 방법 B: 직접 편집 (서버/헤드리스 환경)

```bash
cp .claude/settings.example.json .claude/settings.json
nano .claude/settings.json
```

수정 항목:
```json
"user": {
  "email": "you@company.com"
},
"confluence": {
  "domain": "https://yourcompany.atlassian.net"
},
"weeklyReport": {
  "defaultSpaces": ["DEVWIKI"]
},
"apiKeys": {
  "atlassian": "ATATT3x..."
}
```

---

## 4단계 — MCP 등록

```bash
claude mcp add atlassian-rovo \
  --transport sse \
  https://mcp.atlassian.com/v1/mcp

# 확인
claude mcp list
```

---

## 5단계 — 실행

```bash
cd ~/naru
claude
```

---

## 배치 자동화 설정 (cron)

### 1. settings.json 수정

```json
"scheduleConfig": {
  "enabled": true,
  "spaces": ["DEVWIKI"],
  "publish": false
}
```

### 2. 스케줄 등록

```bash
chmod +x scripts/setup_schedule_linux.sh
bash scripts/setup_schedule_linux.sh install
```

수동으로 crontab에 추가하는 경우:
```bash
crontab -e
```

아래 줄 추가 (매주 월요일 09:00):
```
0 9 * * 1 cd ~/naru && bash scripts/run_weekly_report.sh >> _logs/cron.log 2>&1
```

### 3. 확인 및 관리

```bash
bash scripts/setup_schedule_linux.sh status    # 상태 확인
bash scripts/setup_schedule_linux.sh run       # 즉시 테스트
bash scripts/setup_schedule_linux.sh uninstall # 스케줄 해제
```

### systemd 서비스 사용 (선택)

더 안정적인 스케줄링을 원하면 systemd timer를 사용할 수 있습니다.

`~/.config/systemd/user/naru.service`:
```ini
[Unit]
Description=NaRu Weekly Report

[Service]
Type=oneshot
WorkingDirectory=%h/naru
ExecStart=/bin/bash scripts/run_weekly_report.sh
```

`~/.config/systemd/user/naru.timer`:
```ini
[Unit]
Description=NaRu Weekly Timer

[Timer]
OnCalendar=Mon 09:00
Persistent=true

[Install]
WantedBy=timers.target
```

```bash
systemctl --user enable --now naru.timer
systemctl --user status naru.timer
```

---

## Confluence 업로드

```bash
python3 scripts/upload_to_confluence.py --list
python3 scripts/upload_to_confluence.py --dry-run
python3 scripts/upload_to_confluence.py
```

---

## 문제 해결

**`claude` 명령어를 찾을 수 없음**
```bash
# PATH 확인
echo $PATH
# Claude Code 설치 경로를 PATH에 추가
export PATH="$PATH:/path/to/claude"
```

**권한 오류 (Permission denied)**
```bash
chmod +x scripts/*.sh
chmod +x scripts/upload_to_confluence.py
```

**MCP 인증 오류**
```bash
# settings.json의 apiKeys.atlassian 값 확인
cat .claude/settings.json | python3 -c "import json,sys; d=json.load(sys.stdin); print(d['apiKeys']['atlassian'][:10])"
```
