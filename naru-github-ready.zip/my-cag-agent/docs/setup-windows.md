# Windows 설치 가이드

Windows에서는 **WSL 2** (Windows Subsystem for Linux) 사용을 권장합니다.
Claude Code가 WSL 환경에서 가장 안정적으로 동작합니다.

## 방법 선택

| 방법 | 권장 | 특징 |
|---|---|---|
| **WSL 2** | ✅ 권장 | 가장 안정적, Linux 가이드와 동일하게 사용 |
| **PowerShell + Git Bash** | 가능 | 배치 자동화 제한 있음 |

---

## 방법 A: WSL 2 (권장)

### WSL 2 설치

PowerShell을 **관리자 권한**으로 열고:

```powershell
wsl --install
```

재부팅 후 Ubuntu를 시작합니다.

이후 **Linux 설치 가이드**를 그대로 따릅니다 → [setup-linux.md](setup-linux.md)

WSL 내에서 프로젝트 경로:
```bash
# Windows의 C:\Users\{이름}\naru 에 클론한 경우
cd /mnt/c/Users/{이름}/naru
claude
```

---

## 방법 B: PowerShell + Git Bash

### 사전 요건 설치

**1. Python**
[python.org/downloads](https://www.python.org/downloads/) 에서 3.9 이상 설치.
설치 시 **"Add Python to PATH"** 반드시 체크.

```powershell
python --version  # 확인
```

**2. Git**
[git-scm.com](https://git-scm.com/download/win) 에서 설치.
Git Bash가 함께 설치됩니다.

**3. Claude Code**
Claude Code 공식 사이트에서 Windows 버전 설치.

---

### 1단계 — 저장소 클론

PowerShell 또는 Git Bash에서:

```powershell
git clone https://github.com/{your-username}/naru.git %USERPROFILE%\naru
cd %USERPROFILE%\naru
```

---

### 2단계 — Atlassian API 토큰 발급

1. [id.atlassian.com/manage-profile/security/api-tokens](https://id.atlassian.com/manage-profile/security/api-tokens) 접속
2. **Create API token** → 이름 입력 → 생성
3. 토큰 값 복사

---

### 3단계 — 설정

브라우저에서 `tools\cag-settings.html` 열기:

```powershell
start tools\cag-settings.html
```

설정 입력 후 **settings.json 다운로드** → `.claude\` 폴더에 복사:

```powershell
copy %USERPROFILE%\Downloads\settings.json .claude\settings.json
```

---

### 4단계 — MCP 등록

PowerShell에서:

```powershell
claude mcp add atlassian-rovo `
  --transport sse `
  https://mcp.atlassian.com/v1/mcp

# 확인
claude mcp list
```

---

### 5단계 — 실행

```powershell
cd %USERPROFILE%\naru
claude
```

---

### 배치 자동화 (작업 스케줄러)

Windows에서 자동 실행은 **작업 스케줄러**를 사용합니다.

**1. settings.json 수정**

```json
"scheduleConfig": {
  "enabled": true,
  "spaces": ["DEVWIKI"]
}
```

**2. 작업 등록**

PowerShell (관리자 권한):

```powershell
$action = New-ScheduledTaskAction `
  -Execute "python" `
  -Argument "scripts\upload_to_confluence.py" `
  -WorkingDirectory "$env:USERPROFILE\naru"

$trigger = New-ScheduledTaskTrigger `
  -Weekly `
  -DaysOfWeek Monday `
  -At 9am

Register-ScheduledTask `
  -TaskName "NaRu-WeeklyReport" `
  -Action $action `
  -Trigger $trigger `
  -RunLevel Highest
```

또는 **작업 스케줄러 GUI**:
1. Win + R → `taskschd.msc`
2. 작업 만들기 → 트리거: 매주 월요일 09:00
3. 동작: `python scripts\run_weekly_report.bat`

**3. 배치 파일 직접 실행 (테스트)**

```powershell
.\scripts\run_weekly_report.bat
```

---

### Confluence 업로드

```powershell
# 보고서 목록
python scripts\upload_to_confluence.py --list

# 드라이런
python scripts\upload_to_confluence.py --dry-run

# 업로드
python scripts\upload_to_confluence.py
```

---

## 문제 해결

**`python` 대신 `python3` 사용 필요한 경우**

Windows에서 `python`과 `python3` 명칭이 다를 수 있습니다:

```powershell
# 확인
python --version
python3 --version

# python3가 동작하면 스크립트 호출 시 python3 사용
python3 scripts\upload_to_confluence.py
```

**인코딩 오류 (한글 깨짐)**

```powershell
# PowerShell UTF-8 설정
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$env:PYTHONIOENCODING = "utf-8"
```

**WSL로 전환 권장 상황**

- 배치 스크립트(`.sh`)가 동작하지 않을 때
- MCP 연결이 불안정할 때
- Git Bash에서 경로 문제가 발생할 때

WSL 설치 후 Linux 가이드를 따르는 것이 가장 빠릅니다.
