# macOS 설치 가이드

## 사전 요건

| 항목 | 확인 방법 |
|---|---|
| macOS 12 이상 | 시스템 설정 → 일반 → 소프트웨어 업데이트 |
| Claude Code | `claude --version` |
| Python 3.9+ | `python3 --version` |
| Atlassian 계정 | Confluence 읽기·쓰기 권한 보유 |

Python이 없으면:
```bash
brew install python3
```

---

## 1단계 — 저장소 클론

```bash
git clone https://github.com/{your-username}/naru.git ~/desktop/naru
cd ~/desktop/naru
```

---

## 2단계 — Atlassian API 토큰 발급

1. [id.atlassian.com/manage-profile/security/api-tokens](https://id.atlassian.com/manage-profile/security/api-tokens) 접속
2. **Create API token** 클릭
3. 이름 입력 (예: `naru`) → 생성
4. 토큰 값 복사 (창 닫으면 다시 볼 수 없음)

---

## 3단계 — 설정

브라우저에서 `tools/cag-settings.html` 열기:

```bash
open tools/cag-settings.html
```

아래 항목을 입력:

| 항목 | 예시 |
|---|---|
| 이름 | 홍길동 |
| 이메일 | you@company.com |
| Confluence 도메인 | https://yourcompany.atlassian.net |
| Atlassian API 토큰 | ATATT3x... |

**settings.json 다운로드** → `.claude/` 폴더에 저장:

```bash
cp ~/Downloads/settings.json .claude/settings.json
```

---

## 4단계 — MCP 등록

```bash
claude mcp add atlassian-rovo \
  --transport sse \
  https://mcp.atlassian.com/v1/mcp
```

확인:
```bash
claude mcp list
# atlassian-rovo 가 목록에 표시되면 완료
```

---

## 5단계 — 실행

```bash
cd ~/desktop/naru
claude
```

메인 메뉴가 표시되면 설치 완료.

---

## 배치 자동화 설정 (선택)

매주 특정 시각에 자동으로 주간보고를 생성하려면:

### 1. settings.json 수정

```json
"scheduleConfig": {
  "enabled": true,
  "dayOfWeek": "monday",
  "time": "09:00",
  "spaces": ["DEVWIKI"],
  "publish": false
}
```

### 2. 스케줄 등록

```bash
chmod +x scripts/setup_schedule.sh
bash scripts/setup_schedule.sh install
```

### 3. 확인 및 관리

```bash
bash scripts/setup_schedule.sh status    # 상태 확인
bash scripts/setup_schedule.sh run       # 즉시 테스트
bash scripts/setup_schedule.sh uninstall # 스케줄 해제
```

실행 시각 변경: `scripts/com.naru.weekly.plist` 에서 `Hour` / `Weekday` 수정 후 재등록.

| Weekday 값 | 요일 |
|---|---|
| 1 | 월요일 |
| 2 | 화요일 |
| 5 | 금요일 |

---

## Confluence 업로드 (선택)

주간보고 파일을 Confluence에 직접 업로드:

```bash
# 보고서 목록 확인
python3 scripts/upload_to_confluence.py --list

# 드라이런 (변환만, 업로드 없음)
python3 scripts/upload_to_confluence.py --dry-run

# 실제 업로드 (기본 스페이스, 최신 보고서)
python3 scripts/upload_to_confluence.py

# 스페이스·파일 지정
python3 scripts/upload_to_confluence.py \
  --file _reports/weekly_2025-03.md \
  --space DEVWIKI
```

---

## 문제 해결

**`claude` 명령어를 찾을 수 없음**
```bash
# Claude Code 설치 확인
which claude
# 없으면 Claude Code 공식 사이트에서 재설치
```

**MCP 인증 오류 (401)**
```bash
# API 토큰 만료 여부 확인
# id.atlassian.com에서 토큰 재발급 후 settings.json 업데이트
```

**Python 버전 오류**
```bash
python3 --version  # 3.9 이상 필요
brew upgrade python3
```
