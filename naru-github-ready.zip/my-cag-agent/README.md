# NaRu

Confluence 위키 기반 지식 수집·주간보고 자동화 시스템.
Claude Code 위에서 동작하는 에이전트 팀으로, MCP를 통해 Confluence에 직접 접근합니다.

## 기능

| # | 기능 | 설명 |
|---|---|---|
| 1 | 위키 동기화 | Confluence 스페이스를 로컬에 캐싱 |
| 2 | 주간보고 생성 | 기간별 업데이트 문서 분석 후 보고서 자동 작성 |
| 3 | 지식 컴파일 | 주제별 관련 문서 전체 수집·정리 |
| 4 | Q&A | 위키 기반 단답 질문 처리 |
| 5 | Confluence 업로드 | 생성된 보고서를 Confluence에 직접 게시 |
| 6 | 배치 자동화 | 매주 지정 시각 자동 실행 |

## 실행 환경

| 항목 | 조건 |
|---|---|
| Claude Code | 최신 버전 |
| Python | 3.9 이상 |
| Atlassian 계정 | Confluence 읽기·쓰기 권한 |
| OS | macOS · Linux · Windows (WSL 권장) |

## 빠른 시작

```bash
# 1. 저장소 클론
git clone https://github.com/{your-username}/naru.git
cd naru

# 2. 설정 파일 생성
cp .claude/settings.example.json .claude/settings.json
# tools/cag-settings.html 브라우저로 열어 설정 후 settings.json 저장

# 3. Atlassian Rovo MCP 등록
claude mcp add atlassian-rovo \
  --transport sse \
  https://mcp.atlassian.com/v1/mcp

# 4. 실행
claude
```

## 운영체제별 설치 가이드

- [macOS 설치 가이드](docs/setup-macos.md)
- [Linux 설치 가이드](docs/setup-linux.md)
- [Windows 설치 가이드](docs/setup-windows.md)

## 설정

`tools/cag-settings.html` 을 브라우저로 열면 GUI로 설정할 수 있습니다.

> **주의** `settings.json` 에는 API 키가 포함됩니다. `.gitignore` 에 등록되어 있으므로 절대 커밋하지 마세요.

## 디렉토리 구조

```
naru/
├── .claude/
│   ├── agents/                  에이전트 정의 (10개)
│   ├── skills/                  스킬 정의 (12개)
│   ├── settings.json            설정 파일 (gitignore됨)
│   └── settings.example.json   설정 템플릿
├── docs/                        운영체제별 가이드
├── scripts/
│   ├── upload_to_confluence.py  Confluence 직접 업로드
│   ├── run_weekly_report.sh     배치 실행 (macOS/Linux)
│   ├── run_weekly_report.bat    배치 실행 (Windows)
│   ├── setup_schedule.sh        스케줄 등록 (macOS)
│   └── setup_schedule_linux.sh  스케줄 등록 (Linux)
├── tools/
│   └── cag-settings.html        설정 GUI
├── _cache/                      동기화 캐시 (gitignore됨)
├── _reports/                    생성된 보고서 (gitignore됨)
└── _logs/                       실행 로그 (gitignore됨)
```

## 아키텍처

```
Confluence (Atlassian Rovo MCP)
        ↓ 동기화
    _cache/                   로컬 캐시 (인덱스 + 본문)
        ↓
  doc-collector               문서 수집·필터링 (LLM)
        ↓
  report-analyst              분석·현황·TODO (LLM)
        ↓
  report-writer               보고서 작성 (LLM)
        ↓
    _reports/                 로컬 마크다운 파일
        ↓ (선택)
  upload_to_confluence.py     REST API 직접 업로드 (Python)
        ↓
  Confluence 페이지
```

## 라이선스

MIT License — [LICENSE](LICENSE) 참조
