#!/bin/bash
set -euo pipefail

AGENT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
LOG_DIR="$AGENT_DIR/_logs"
TIMESTAMP="$(date +%Y%m%d_%H%M%S)"
SCHED_LOG="$LOG_DIR/cron_$TIMESTAMP.log"

mkdir -p "$LOG_DIR"

log() { echo "[$(date '+%H:%M:%S')] $*" | tee -a "$SCHED_LOG"; }

log "=== 자동 실행 시작 ==="

SETTINGS="$AGENT_DIR/.claude/settings.json"
if [[ ! -f "$SETTINGS" ]]; then
    log "ERROR: settings.json 없음"
    exit 1
fi

ENABLED="$(python3 -c "
import json, sys
d = json.load(open('$SETTINGS'))
print(str(d.get('scheduleConfig', {}).get('enabled', False)).lower())
" 2>/dev/null || echo 'false')"

if [[ "$ENABLED" != "true" ]]; then
    log "scheduleConfig.enabled = false — 건너뜀"
    exit 0
fi

SPACES="$(python3 -c "
import json
d = json.load(open('$SETTINGS'))
sp = d.get('scheduleConfig', {}).get('spaces', [])
print(' '.join(sp))
" 2>/dev/null || echo '')"

PUBLISH="$(python3 -c "
import json
d = json.load(open('$SETTINGS'))
print(str(d.get('scheduleConfig', {}).get('publish', False)).lower())
" 2>/dev/null || echo 'false')"

if ! command -v claude &>/dev/null; then
    log "ERROR: claude 명령어 없음 (PATH 확인)"
    exit 1
fi

CMD="주간보고 생성 --yes"
[[ -n "$SPACES" ]] && CMD="$SPACES 주간보고 생성 --yes"
[[ "$PUBLISH" == "true" ]] && CMD="$CMD --publish"

log "명령: $CMD"
cd "$AGENT_DIR"

if claude --print "$CMD" >> "$SCHED_LOG" 2>&1; then
    log "=== 완료 ==="
else
    log "=== 오류 (종료 코드: $?) ==="
    exit 1
fi
