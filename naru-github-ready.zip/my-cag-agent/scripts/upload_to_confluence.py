#!/usr/bin/env python3
from __future__ import annotations

import argparse
import base64
import json
import re
import sys
import time
from datetime import datetime, timezone
from pathlib import Path
from urllib import error as urllib_error
from urllib import request
from urllib.parse import quote

SINGLE_PAGE_THRESHOLD_BYTES = 50 * 1024
MAX_RETRIES = 3
RETRY_BASE_DELAY = 2.0
REQUEST_TIMEOUT = 60
BAR_WIDTH = 20
BAR_FILL = "█"
BAR_EMPTY = "░"


def progress(current: int, total: int, label: str = ""):
    filled = int(BAR_WIDTH * current / max(total, 1))
    bar = BAR_FILL * filled + BAR_EMPTY * (BAR_WIDTH - filled)
    pct = int(100 * current / max(total, 1))
    suffix = f"  {current}/{total}"
    label_str = f"  {label[:40]}" if label else ""
    print(f"\r[{bar}] {pct:3d}%{suffix}{label_str}", end="", flush=True)
    if current >= total:
        print()


def warn(title: str, detail: str, action: str = ""):
    print(f"\n{'━'*44}")
    print(f"⚠ 경고  {title}")
    print(f"  원인: {detail}")
    if action:
        print(f"  조치: {action}")
    print(f"{'━'*44}")


def load_settings(base_dir: Path) -> dict:
    path = base_dir / ".claude" / "settings.json"
    if not path.exists():
        die(f"settings.json 없음: {path}")
    return json.loads(path.read_text(encoding="utf-8"))


def get_credentials(settings: dict) -> tuple:
    cf = settings.get("confluence", {})
    domain = cf.get("domain", "").rstrip("/")
    parent_page = cf.get("reportParentPage", "")
    email = settings.get("user", {}).get("email", "")
    token = settings.get("apiKeys", {}).get("atlassian", "")

    missing = [k for k, v in [
        ("confluence.domain", domain),
        ("user.email", email),
        ("apiKeys.atlassian", token),
    ] if not v]

    if missing:
        die(
            f"settings.json 누락: {', '.join(missing)}\n"
            "cag-settings.html 에서 설정하거나 직접 수정하세요."
        )
    return domain, email, token, parent_page


def die(msg: str, code: int = 1):
    print(f"[ERROR] {msg}", file=sys.stderr)
    sys.exit(code)


def log(msg: str):
    print(f"[{datetime.now().strftime('%H:%M:%S')}] {msg}")


def auth_header(email: str, token: str) -> str:
    return "Basic " + base64.b64encode(f"{email}:{token}".encode()).decode()


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def api_call(
    domain: str,
    email: str,
    token: str,
    method: str,
    path: str,
    body: dict | None = None,
) -> dict:
    url = f"{domain}/wiki/rest/api/{path.lstrip('/')}"
    headers = {
        "Authorization": auth_header(email, token),
        "Content-Type": "application/json",
        "Accept": "application/json",
        "X-Atlassian-Token": "no-check",
    }
    data = json.dumps(body).encode("utf-8") if body else None

    for attempt in range(1, MAX_RETRIES + 1):
        try:
            req = request.Request(url, data=data, headers=headers, method=method)
            with request.urlopen(req, timeout=REQUEST_TIMEOUT) as resp:
                return json.loads(resp.read().decode("utf-8"))

        except urllib_error.HTTPError as e:
            status = e.code
            body_text = e.read().decode("utf-8", errors="replace")

            if status in (401, 403):
                print()
                print(f"\n{'━'*44}")
                print(f"✗ 오류  Confluence 인증 오류 ({status})")
                print(f"  원인: user.email 또는 apiKeys.atlassian 오류")
                print(f"  확인: https://id.atlassian.com/manage-profile/security/api-tokens")
                print(f"{'━'*44}")
                die(f"인증 오류 ({status})")
            if status == 404:
                print()
                die(f"404: {url}\nconfluence.domain 확인.")

            delay = RETRY_BASE_DELAY * (2 ** (attempt - 1))
            if attempt < MAX_RETRIES:
                print(f"\n  ℹ 재시도  HTTP {status} — {delay:.0f}초 후 재시도 ({attempt}/{MAX_RETRIES})")
                time.sleep(delay)
            else:
                print()
                print(f"\n{'━'*44}")
                print(f"✗ 오류  API 오류 {status} ({MAX_RETRIES}회 실패)")
                print(f"  응답: {body_text[:200]}")
                print(f"{'━'*44}")
                die(f"API 오류 {status}")

        except TimeoutError:
            delay = RETRY_BASE_DELAY * (2 ** (attempt - 1))
            if attempt < MAX_RETRIES:
                print(f"\n  ℹ 재시도  타임아웃 ({REQUEST_TIMEOUT}초) — {delay:.0f}초 후 재시도 ({attempt}/{MAX_RETRIES})")
                time.sleep(delay)
            else:
                print()
                print(f"\n{'━'*44}")
                print(f"✗ 오류  타임아웃 반복")
                print(f"  원인: 응답 없음 ({REQUEST_TIMEOUT}초, {MAX_RETRIES}회)")
                print(f"  조치: 네트워크 상태 확인 또는 --dry-run 으로 변환만 테스트")
                print(f"{'━'*44}")
                die("타임아웃")

        except Exception as e:
            die(f"네트워크 오류: {e}")

    die("알 수 없는 오류")


def find_page(domain: str, email: str, token: str, space: str, title: str) -> dict | None:
    try:
        result = api_call(
            domain, email, token, "GET",
            f"content?title={quote(title)}&spaceKey={space}&expand=version",
        )
        results = result.get("results", [])
        return results[0] if results else None
    except SystemExit:
        return None


def find_parent_id(domain: str, email: str, token: str, space: str, title: str) -> str | None:
    if not title:
        return None
    page = find_page(domain, email, token, space, title)
    return page["id"] if page else None


def create_page(
    domain: str, email: str, token: str,
    space: str, title: str, storage_body: str,
    parent_id: str | None = None,
) -> dict:
    body: dict = {
        "type": "page",
        "title": title,
        "space": {"key": space},
        "body": {"storage": {"value": storage_body, "representation": "storage"}},
    }
    if parent_id:
        body["ancestors"] = [{"id": parent_id}]
    return api_call(domain, email, token, "POST", "content", body)


def update_page(
    domain: str, email: str, token: str,
    page_id: str, title: str, storage_body: str, version: int,
) -> dict:
    return api_call(domain, email, token, "PUT", f"content/{page_id}", {
        "type": "page",
        "title": title,
        "version": {"number": version + 1},
        "body": {"storage": {"value": storage_body, "representation": "storage"}},
    })


def upsert_page(
    domain: str, email: str, token: str,
    space: str, title: str, storage_body: str,
    parent_id: str | None = None,
) -> tuple:
    existing = find_page(domain, email, token, space, title)
    if existing:
        ver = existing["version"]["number"]
        return update_page(domain, email, token, existing["id"], title, storage_body, ver), "updated"
    return create_page(domain, email, token, space, title, storage_body, parent_id), "created"


def page_url(domain: str, result: dict) -> str:
    return domain + "/wiki" + result.get("_links", {}).get("webui", "")


# ── Markdown → Storage Format ─────────────────────────────────────────────────

def md_to_storage(md: str) -> str:
    code_blocks: list[str] = []
    inline_codes: list[str] = []

    def protect_code(m: re.Match) -> str:
        lang = m.group(1).strip() or "none"
        code = m.group(2)
        macro = (
            '<ac:structured-macro ac:name="code">'
            f'<ac:parameter ac:name="language">{lang}</ac:parameter>'
            f'<ac:plain-text-body><![CDATA[{code}]]></ac:plain-text-body>'
            '</ac:structured-macro>'
        )
        code_blocks.append(macro)
        return f"\x00CB{len(code_blocks)-1}\x00"

    def protect_inline(m: re.Match) -> str:
        inline_codes.append(f"<code>{_esc(m.group(1))}</code>")
        return f"\x00IC{len(inline_codes)-1}\x00"

    md = re.sub(r"```(\w*)\n(.*?)```", protect_code, md, flags=re.DOTALL)
    md = re.sub(r"`([^`\n]+)`", protect_inline, md)

    lines = md.split("\n")
    output: list[str] = []
    i = 0

    while i < len(lines):
        line = lines[i]

        m = re.match(r"^(#{1,6})\s+(.*)", line)
        if m:
            lvl = len(m.group(1))
            output.append(f"<h{lvl}>{_inline(m.group(2))}</h{lvl}>")
            i += 1
            continue

        if re.match(r"^[-*_]{3,}\s*$", line):
            output.append("<hr/>")
            i += 1
            continue

        if ("|" in line
                and i + 1 < len(lines)
                and re.match(r"^\s*\|[\-| :]+\|\s*$", lines[i + 1])):
            table_lines: list[str] = []
            while i < len(lines) and "|" in lines[i]:
                table_lines.append(lines[i])
                i += 1
            output.append(_table(table_lines))
            continue

        if re.match(r"^[-*+]\s+", line):
            block, i = _collect_list(lines, i, ordered=False)
            output.append(block)
            continue

        if re.match(r"^\d+\.\s+", line):
            block, i = _collect_list(lines, i, ordered=True)
            output.append(block)
            continue

        if line.startswith("> "):
            quote_lines: list[str] = []
            while i < len(lines) and lines[i].startswith("> "):
                quote_lines.append(lines[i][2:])
                i += 1
            output.append(f"<blockquote>{md_to_storage(chr(10).join(quote_lines))}</blockquote>")
            continue

        if not line.strip():
            output.append("")
            i += 1
            continue

        output.append(f"<p>{_inline(line)}</p>")
        i += 1

    result = "\n".join(output)
    for idx, block in enumerate(code_blocks):
        result = result.replace(f"\x00CB{idx}\x00", block)
    for idx, ic in enumerate(inline_codes):
        result = result.replace(f"\x00IC{idx}\x00", ic)
    return result


def _esc(s: str) -> str:
    return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def _inline(s: str) -> str:
    s = re.sub(r"\*\*\*(.+?)\*\*\*", r"<strong><em>\1</em></strong>", s)
    s = re.sub(r"\*\*(.+?)\*\*",     r"<strong>\1</strong>", s)
    s = re.sub(r"__(.+?)__",          r"<strong>\1</strong>", s)
    s = re.sub(r"\*(.+?)\*",          r"<em>\1</em>", s)
    s = re.sub(r"_(.+?)_",            r"<em>\1</em>", s)
    s = re.sub(r"~~(.+?)~~",          r"<del>\1</del>", s)
    s = re.sub(r"\[([^\]]+)\]\(([^)]+)\)", r'<a href="\2">\1</a>', s)
    s = re.sub(r"!\[([^\]]*)\]\(([^)]+)\)", r'<img src="\2" alt="\1"/>', s)
    return s


def _parse_row(line: str) -> list[str]:
    return [cell.strip() for cell in line.strip().strip("|").split("|")]


def _table(lines: list[str]) -> str:
    if len(lines) < 2:
        return ""
    header = _parse_row(lines[0])
    data_rows = [_parse_row(l) for l in lines[2:]]
    n = len(header)

    html = ["<table><tbody>"]
    html.append("<tr>" + "".join(f"<th><strong>{_inline(c)}</strong></th>" for c in header) + "</tr>")
    for row in data_rows:
        row += [""] * (n - len(row))
        html.append("<tr>" + "".join(f"<td>{_inline(c)}</td>" for c in row[:n]) + "</tr>")
    html.append("</tbody></table>")
    return "\n".join(html)


def _collect_list(lines: list[str], i: int, ordered: bool) -> tuple:
    tag = "ol" if ordered else "ul"
    pattern = r"^\d+\.\s+" if ordered else r"^[-*+]\s+"
    items: list[str] = []
    while i < len(lines) and re.match(pattern, lines[i]):
        content = re.sub(pattern, "", lines[i])
        items.append(f"<li><p>{_inline(content)}</p></li>")
        i += 1
    return f"<{tag}>{''.join(items)}</{tag}>", i


# ── 분할 ─────────────────────────────────────────────────────────────────────

def split_sections(md: str) -> tuple:
    lines = md.split("\n")
    intro: list[str] = []
    sections: list[tuple] = []
    cur_title: str | None = None
    cur_body: list[str] = []

    for line in lines:
        m = re.match(r"^##\s+(.+)", line)
        if m:
            if cur_title is not None:
                sections.append((cur_title, cur_body[:]))
            else:
                intro = cur_body[:]
            cur_title = m.group(1).strip()
            cur_body = []
        else:
            cur_body.append(line)

    if cur_title is not None:
        sections.append((cur_title, cur_body[:]))
    elif not sections:
        intro = cur_body[:]

    return "\n".join(intro), [(t, "\n".join(b)) for t, b in sections]


def build_summary(title: str, sections: list[tuple], intro_md: str) -> str:
    lines = [intro_md, "", "## 목차", ""]
    for sec_title, _ in sections:
        lines.append(f"- {sec_title}")
    return "\n".join(lines)


# ── 업로드 ────────────────────────────────────────────────────────────────────

def upload_single(
    domain: str, email: str, token: str,
    space: str, title: str, md: str,
    parent_id: str | None, dry_run: bool,
) -> list[dict]:
    storage = md_to_storage(md)
    progress(0, 1, "마크다운 변환 중...")
    if dry_run:
        progress(1, 1, "변환 완료 (DRY-RUN)")
        log(f"[DRY-RUN] 단일 페이지: '{title}' ({len(storage):,}자)")
        return [{"dry_run": True, "title": title}]
    progress(1, 1, "변환 완료  →  업로드 중...")
    log(f"'{title}' 업로드 중...")
    result, action = upsert_page(domain, email, token, space, title, storage, parent_id)
    url = page_url(domain, result)
    log(f"  {action}: {url}")
    return [{"action": action, "url": url, "id": result.get("id"), "type": "single"}]


def upload_split(
    domain: str, email: str, token: str,
    space: str, title: str, md: str,
    parent_id: str | None, dry_run: bool,
) -> list[dict]:
    intro_md, sections = split_sections(md)

    if not sections:
        log("## 헤딩 없음 — 단일 페이지로 업로드")
        return upload_single(domain, email, token, space, title, md, parent_id, dry_run)

    total = len(sections) + 1
    log(f"분할 업로드: 상위 1 + 하위 {len(sections)}  (총 {total}페이지)")
    results: list[dict] = []
    done = 0

    summary_md = build_summary(title, sections, intro_md)
    summary_storage = md_to_storage(summary_md)

    if dry_run:
        done += 1
        progress(done, total, f"[DRY-RUN] 상위: {title[:30]}")
        parent_page_id = "DRY_RUN"
        results.append({"dry_run": True, "title": title, "type": "parent"})
    else:
        progress(done, total, "상위 페이지 업로드 중...")
        result, action = upsert_page(domain, email, token, space, title, summary_storage, parent_id)
        parent_page_id = result["id"]
        url = page_url(domain, result)
        done += 1
        progress(done, total, f"{action}: {title[:30]}")
        results.append({"action": action, "url": url, "id": parent_page_id, "type": "parent"})

    for sec_title, sec_body in sections:
        child_title = f"{title} — {sec_title}"
        child_storage = md_to_storage(sec_body)
        if dry_run:
            done += 1
            progress(done, total, f"[DRY-RUN] {sec_title[:30]}")
            results.append({"dry_run": True, "title": child_title, "type": "child"})
        else:
            progress(done, total, f"업로드 중: {sec_title[:30]}")
            result, action = upsert_page(
                domain, email, token, space, child_title, child_storage, parent_page_id
            )
            url = page_url(domain, result)
            done += 1
            progress(done, total, f"{action}: {sec_title[:30]}")
            results.append({"action": action, "url": url, "id": result.get("id"), "type": "child"})

    print()
    return results


# ── 파일 탐색 / 로그 ──────────────────────────────────────────────────────────

def find_latest_report(base_dir: Path) -> Path | None:
    d = base_dir / "_reports"
    if not d.exists():
        return None
    candidates = sorted(d.glob("weekly_*.md"), reverse=True)
    return candidates[0] if candidates else None


def list_reports(base_dir: Path):
    d = base_dir / "_reports"
    files = sorted(d.glob("weekly_*.md"), reverse=True) if d.exists() else []
    if not files:
        print("_reports/ 에 파일이 없습니다.")
        return
    for f in files:
        print(f"  {f.name}  ({f.stat().st_size / 1024:.1f} KB)")


def save_log(base_dir: Path, data: dict) -> Path:
    d = base_dir / "_logs"
    d.mkdir(exist_ok=True)
    ts = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
    p = d / f"upload_{ts}.json"
    p.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    return p


# ── 메인 ─────────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(description="Confluence 직접 업로드")
    parser.add_argument("--file",    help="업로드할 마크다운 파일")
    parser.add_argument("--space",   help="Confluence 스페이스 키")
    parser.add_argument("--title",   help="페이지 제목")
    parser.add_argument("--parent",  help="상위 페이지 제목")
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--list",    action="store_true")
    args = parser.parse_args()

    base_dir = Path(__file__).resolve().parent.parent

    if args.list:
        list_reports(base_dir)
        return

    settings = load_settings(base_dir)
    domain, email, token, default_parent = get_credentials(settings)

    weekly_cfg = settings.get("weeklyReport", {})
    spaces = weekly_cfg.get("defaultSpaces") or []
    space = args.space or (spaces[0] if spaces else "")
    if not space:
        die("스페이스 키 없음. --space DEVWIKI 또는 settings.json의 weeklyReport.defaultSpaces 설정")

    if args.file:
        md_path = Path(args.file)
        if not md_path.is_absolute():
            md_path = base_dir / md_path
    else:
        md_path = find_latest_report(base_dir)
        if not md_path:
            die("보고서 없음. --file 로 경로 지정 또는 --list 로 확인")
        log(f"자동 탐색: {md_path.name}")

    if not md_path.exists():
        die(f"파일 없음: {md_path}")

    md_content = md_path.read_text(encoding="utf-8")
    file_size = md_path.stat().st_size
    log(f"파일: {md_path.name} ({file_size / 1024:.1f} KB)")

    if args.title:
        title = args.title
    else:
        stem = md_path.stem.replace("_", " ")
        title = f"주간보고 {stem.split()[-1]}" if "weekly" in md_path.stem else stem

    log(f"제목: {title} / 스페이스: {space}")

    parent_title = args.parent or default_parent
    parent_id: str | None = None
    if parent_title and not args.dry_run:
        log(f"상위 페이지 탐색: '{parent_title}'")
        parent_id = find_parent_id(domain, email, token, space, parent_title)
        if parent_id:
            log(f"  ID: {parent_id}")
        else:
            log(f"  없음 — 루트에 생성")

    if args.dry_run:
        log("[DRY-RUN] 실제 업로드 없음")

    started = now_iso()
    if file_size >= SINGLE_PAGE_THRESHOLD_BYTES:
        log(f"{file_size / 1024:.1f} KB ≥ {SINGLE_PAGE_THRESHOLD_BYTES // 1024} KB → 분할")
        results = upload_split(domain, email, token, space, title, md_content, parent_id, args.dry_run)
    else:
        log(f"{file_size / 1024:.1f} KB < {SINGLE_PAGE_THRESHOLD_BYTES // 1024} KB → 단일")
        results = upload_single(domain, email, token, space, title, md_content, parent_id, args.dry_run)

    log_data = {
        "type": "upload",
        "started_at": started,
        "ended_at": now_iso(),
        "dry_run": args.dry_run,
        "file": str(md_path),
        "file_size_kb": round(file_size / 1024, 1),
        "space": space,
        "title": title,
        "strategy": "split" if len(results) > 1 else "single",
        "pages": results,
    }
    if not args.dry_run:
        lp = save_log(base_dir, log_data)
        log(f"로그: {lp.name}")

    print("\n" + "━" * 44)
    if args.dry_run:
        print(f" DRY-RUN 완료 — {len(results)}페이지 예정")
    else:
        created = sum(1 for r in results if r.get("action") == "created")
        updated = sum(1 for r in results if r.get("action") == "updated")
        print(f" 완료  생성 {created} / 업데이트 {updated}")
        parents = [r for r in results if r.get("type") in ("single", "parent")]
        if parents:
            print(f" URL: {parents[0].get('url', '')}")
    print("━" * 44)


if __name__ == "__main__":
    main()
