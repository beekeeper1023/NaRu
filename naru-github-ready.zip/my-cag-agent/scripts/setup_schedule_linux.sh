#!/bin/bash
set -euo pipefail

AGENT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
CRON_TAG="# naru-weekly"
CRON_JOB="0 9 * * 1 cd $AGENT_DIR && bash scripts/run_weekly_report.sh >> _logs/cron.log 2>&1 $CRON_TAG"

cmd="${1:-}"

case "$cmd" in
    install)
        SETTINGS="$AGENT_DIR/.claude/settings.json"
        if [[ ! -f "$SETTINGS" ]]; then
            echo "ERROR: settings.json 없음"
            exit 1
        fi

        ENABLED="$(python3 -c "
import json
d = json.load(open('$SETTINGS'))
print(str(d.get('scheduleConfig', {}).get('enabled', False)).lower())
" 2>/dev/null || echo 'false')"

        if [[ "$ENABLED" != "true" ]]; then
            echo "settings.json의 scheduleConfig.enabled 가 false입니다."
            echo "true 로 변경한 뒤 다시 실행하세요."
            exit 1
        fi

        mkdir -p "$AGENT_DIR/_logs"

        if crontab -l 2>/dev/null | grep -q "$CRON_TAG"; then
            echo "이미 등록되어 있습니다."
            crontab -l | grep "$CRON_TAG"
        else
            (crontab -l 2>/dev/null; echo "$CRON_JOB") | crontab -
            echo "등록 완료: 매주 월요일 09:00"
        fi
        ;;

    uninstall)
        if crontab -l 2>/dev/null | grep -q "$CRON_TAG"; then
            crontab -l | grep -v "$CRON_TAG" | crontab -
            echo "해제 완료"
        else
            echo "등록된 스케줄 없음"
        fi
        ;;

    status)
        if crontab -l 2>/dev/null | grep -q "$CRON_TAG"; then
            echo "상태: 등록됨"
            crontab -l | grep "$CRON_TAG"
        else
            echo "상태: 미등록"
        fi
        LATEST="$(ls -t "$AGENT_DIR/_logs/cron"*.log 2>/dev/null | head -1 || echo '')"
        if [[ -n "$LATEST" ]]; then
            echo "--- 최근 로그: $LATEST ---"
            tail -5 "$LATEST"
        fi
        ;;

    run)
        bash "$AGENT_DIR/scripts/run_weekly_report.sh"
        ;;

    *)
        echo "사용법: $0 {install|uninstall|status|run}"
        exit 1
        ;;
esac
