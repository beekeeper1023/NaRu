@echo off
setlocal enabledelayedexpansion

set AGENT_DIR=%~dp0..
set LOG_DIR=%AGENT_DIR%\_logs
set TIMESTAMP=%date:~0,4%%date:~5,2%%date:~8,2%_%time:~0,2%%time:~3,2%%time:~6,2%
set TIMESTAMP=%TIMESTAMP: =0%
set SCHED_LOG=%LOG_DIR%\cron_%TIMESTAMP%.log

if not exist "%LOG_DIR%" mkdir "%LOG_DIR%"

echo [%time%] === 자동 실행 시작 === >> "%SCHED_LOG%"

set SETTINGS=%AGENT_DIR%\.claude\settings.json
if not exist "%SETTINGS%" (
    echo [%time%] ERROR: settings.json 없음 >> "%SCHED_LOG%"
    exit /b 1
)

for /f "delims=" %%i in ('python -c "import json; d=json.load(open(r'%SETTINGS%')); print(str(d.get('scheduleConfig',{}).get('enabled',False)).lower())" 2^>nul') do set ENABLED=%%i
if not "%ENABLED%"=="true" (
    echo [%time%] scheduleConfig.enabled = false -- 건너뜀 >> "%SCHED_LOG%"
    exit /b 0
)

for /f "delims=" %%i in ('python -c "import json; d=json.load(open(r'%SETTINGS%')); sp=d.get('scheduleConfig',{}).get('spaces',[]); print(' '.join(sp))" 2^>nul') do set SPACES=%%i
for /f "delims=" %%i in ('python -c "import json; d=json.load(open(r'%SETTINGS%')); print(str(d.get('scheduleConfig',{}).get('publish',False)).lower())" 2^>nul') do set PUBLISH=%%i

where claude >nul 2>&1
if errorlevel 1 (
    echo [%time%] ERROR: claude 명령어 없음 >> "%SCHED_LOG%"
    exit /b 1
)

set CMD=주간보고 생성 --yes
if not "%SPACES%"=="" set CMD=%SPACES% 주간보고 생성 --yes
if "%PUBLISH%"=="true" set CMD=%CMD% --publish

echo [%time%] 명령: %CMD% >> "%SCHED_LOG%"

cd /d "%AGENT_DIR%"
claude --print "%CMD%" >> "%SCHED_LOG%" 2>&1
if errorlevel 1 (
    echo [%time%] === 오류 발생 === >> "%SCHED_LOG%"
    exit /b 1
)

echo [%time%] === 완료 === >> "%SCHED_LOG%"
