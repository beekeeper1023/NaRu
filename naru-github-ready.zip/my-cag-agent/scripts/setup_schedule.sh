#!/bin/bash
set -euo pipefail

AGENT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
PLIST_NAME="com.naru.weekly"
PLIST_SRC="$AGENT_DIR/scripts/$PLIST_NAME.plist"
LAUNCH_AGENTS="$HOME/Library/LaunchAgents"
PLIST_DEST="$LAUNCH_AGENTS/$PLIST_NAME.plist"

cmd="${1:-}"

case "$cmd" in
    install)
        SETTINGS="$AGENT_DIR/.claude/settings.json"
        ENABLED="$(python3 -c "
import json
d = json.load(open('$SETTINGS'))
print(str(d.get('scheduleConfig', {}).get('enabled', False)).lower())
" 2>/dev/null || echo 'false')"

        if [[ "$ENABLED" != "true" ]]; then
            echo "settings.json의 scheduleConfig.enabled 가 false입니다."
            echo "true 로 변경한 뒤 다시 실행하세요."
            exit 1
        fi

        mkdir -p "$LAUNCH_AGENTS"
        sed "s|AGENT_DIR|$AGENT_DIR|g" "$PLIST_SRC" > "$PLIST_DEST"
        launchctl load "$PLIST_DEST"
        echo "등록 완료: 매주 월요일 09:00"
        echo "로그: $AGENT_DIR/_logs/"
        ;;

    uninstall)
        if [[ -f "$PLIST_DEST" ]]; then
            launchctl unload "$PLIST_DEST" 2>/dev/null || true
            rm -f "$PLIST_DEST"
            echo "해제 완료"
        else
            echo "등록된 스케줄 없음"
        fi
        ;;

    status)
        if launchctl list 2>/dev/null | grep -q "$PLIST_NAME"; then
            echo "상태: 등록됨"
            launchctl list "$PLIST_NAME" 2>/dev/null || true
        else
            echo "상태: 미등록"
        fi
        LATEST="$(ls -t "$AGENT_DIR/_logs/cron_"*.log 2>/dev/null | head -1 || echo '')"
        if [[ -n "$LATEST" ]]; then
            echo "--- 최근 로그: $LATEST ---"
            tail -5 "$LATEST"
        fi
        ;;

    run)
        bash "$AGENT_DIR/scripts/run_weekly_report.sh"
        ;;

    *)
        echo "사용법: $0 {install|uninstall|status|run}"
        exit 1
        ;;
esac
