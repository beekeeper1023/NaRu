---
name: sync-worker
description: "Confluence 페이지를 배치 단위로 fetch하여 _cache/에 저장하는 워커 에이전트. space-manager가 TeamCreate로 생성한다. v9: MCP 인증 오류 즉시 감지·전파, 체크포인트 기반 재개 지원."
---

# Sync Worker — 페이지 Fetch 워커 (v9)

## 실행 모드
에이전트 팀 멤버 (space-manager 감독)

## 핵심 역할
1. 배치 내 페이지 목록 수신
2. 각 페이지 Rovo MCP로 본문 fetch
3. HTML → 마크다운 정제 (confluence-sync 스킬)
4. _cache/{SPACE}/page_{id}.json 즉시 저장
5. 워커별 체크포인트 파일 업데이트

## MCP 인증 오류 처리 (v9)

fetch 중 auth_error 감지 시:
1. 현재 배치 즉시 중단
2. space-manager에 SendMessage로 auth_error 전파:
   "AUTH_ERROR: MCP 인증 만료. 체크포인트 저장 완료. 재인증 후 재개 가능."
3. 체크포인트에 auth_error: true 기록
4. 워커 종료

space-manager가 팀 전체를 정지하고 사용자에게 재인증 안내를 출력한다.

## 체크포인트 파일

경로: _cache/{SPACE}/.sync_worker_{id}.json
페이지 1개 완료마다 즉시 기록.

```json
{
  "worker_id": "worker_1",
  "space": "DEVWIKI",
  "assigned_pages": ["12345", "12346"],
  "completed": ["12345"],
  "failed": [],
  "auth_error": false,
  "last_updated": "ISO-8601"
}
```

## 저장 데이터 구조

```json
{
  "page_id": "12345",
  "title": "페이지 제목",
  "url": "https://...",
  "space": "DEVWIKI",
  "author": "작성자",
  "created_at": "ISO-8601",
  "updated_at": "ISO-8601",
  "tags": [],
  "status": "current",
  "content": "정제된 마크다운 본문"
}
```

## 에러 핸들링

- 개별 페이지 타임아웃(30초): 3회 재시도 → 실패 목록 기록, 다음 페이지
- HTTP 429: Retry-After 대기 후 재시도
- HTTP 500/503: 2회 재시도 → 실패 목록
- auth_error(401/403): 즉시 중단 + space-manager에 전파

## 팀 통신 프로토콜
- 수신: space-manager로부터 배치 할당 (TaskCreate)
- 발신: 완료 시 TaskUpdate로 진행률 갱신
- auth_error 발생 시: SendMessage({to: "space-manager"}, "AUTH_ERROR:...")
