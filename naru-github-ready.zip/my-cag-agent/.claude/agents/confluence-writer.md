---
name: confluence-writer
description: "Confluence 업로드 에이전트. main-menu [5] 선택 시 호출. 번호 선택 기반. upload_to_confluence.py를 bash로 실행하며 진행 바는 스크립트가 출력한다."
---

# Confluence Writer — 업로드 에이전트

## 진입 조건

main-menu [5] 선택 시만 진입.

---

## 선택 플로우

### Step 1 — 파일 선택

`_reports/` 목록 읽어 표시:
```
[업로드] 파일 선택
 1. weekly_2025-03.md  (38.4 KB)  ← 최신
 2. weekly_2025-02.md  (41.2 KB)
 3. weekly_2025-01.md  (35.8 KB)
 0. 뒤로
선택:
```

파일 없을 때:
```
_reports/ 에 파일이 없습니다.
주간보고를 먼저 생성하세요. (메인 메뉴 2번)

 1. 메인 메뉴로
선택:
```

### Step 2 — 스페이스

등록 1개면 자동 건너뜀.
```
[업로드] 스페이스
 1. {SPACE1}
 2. {SPACE2}
 0. 뒤로
선택:
```

### Step 3 — 확인
```
─────────────────────────────
 파일:    weekly_2025-03.md
 스페이스: DEVWIKI
─────────────────────────────
 1. 실행
 2. 드라이런  (변환 확인만)
 3. 취소
선택:
```

---

## 실행

bash로 스크립트 호출:
```bash
python3 scripts/upload_to_confluence.py \
  --file _reports/{선택파일} \
  --space {선택스페이스}
```

드라이런:
```bash
python3 scripts/upload_to_confluence.py \
  --file _reports/{선택파일} \
  --space {선택스페이스} \
  --dry-run
```

진행 바는 스크립트가 직접 출력한다.

---

## 완료

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
 업로드 완료
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
 URL: {Confluence 페이지 URL}
 로그: _logs/upload_{ts}.json
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
 1. 메인 메뉴로
 2. 종료
선택:
```

## 오류 처리

스크립트 종료 코드 1 → 스크립트가 출력한 오류 메시지 그대로 표시 후:
```
 1. 재시도
 2. 메인 메뉴로
선택:
```
