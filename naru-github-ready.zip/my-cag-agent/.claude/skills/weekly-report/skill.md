---
name: weekly-report
description: "주간보고 생성 파이프라인 스킬. report-orchestrator가 참조한다. 번호 선택 기반 플로우를 정의한다."
---

# Weekly Report — 주간보고 생성 스킬

## 실행 모드: 서브 에이전트 (파이프라인)

## 진입 방식

main-menu [2] → report-orchestrator → 이 스킬 참조.
자연어 명령으로 직접 진입하지 않는다.

---

## 파이프라인 구성

| Phase | 담당 | 방식 |
|---|---|---|
| 선택 | report-orchestrator | 번호 선택 (Step 1~4) |
| 0 | Orchestrator | workspace 준비, 로그 초기화 |
| 1 | doc-collector | LLM |
| 2 | report-analyst | LLM |
| 3 | report-writer | LLM |
| 4 | confluence-writer | LLM (Step 3에서 2 선택 시) |
| 5 | Orchestrator | 로그 완료, 완료 배너 |

---

## Phase 0: 준비

1. settings.json 로드 (projectMapping)
2. registry.json 확인
3. `_workspace/weekly_{YYYYMMDD}/` 생성
4. `run_context.json` 저장
5. `_logs/pipeline_{ts}.json` 초기화
6. `_reports/` 이전 보고서 탐색

캐시 없을 때:
```
'{SPACE}' 캐시 없음.

 1. 동기화 먼저 실행
 2. 취소
선택:
```

---

## Phase 1: 수집 (doc-collector LLM)

doc-filter 스킬 참조.
분할 인덱스 스페이스는 모든 `_index_*.json` 병합.

완료 보고:
```
[ 1/3 ] 완료 — {N}건 (신규 {a} / 업데이트 {b} / 날짜미상 {c})
```

0건 수집 시: 빈 보고서로 자동 계속 (확인 없음).

---

## Phase 2: 분석 (report-analyst LLM)

`documents_for_analysis` (≤30건)만 읽는다.
`meta` 카운팅 수치는 그대로 사용한다.
이전 보고서가 있으면 `week_over_week` 비교 포함.

완료 보고:
```
[ 2/3 ] 완료 — {N}개 프로젝트 / TODO {M}건
```

Phase 2 실패 시: meta 기반으로 Phase 3 자동 진행 (사용자 확인 없음).

---

## Phase 3: 보고서 작성 (report-writer LLM)

report-writing 스킬 참조.
파일 충돌 시 `_v2` 자동 추가.

완료 보고:
```
[ 3/3 ] 완료
```

---

## Phase 4: Confluence 게시 (선택)

Step 3에서 2를 선택한 경우만.
upload_to_confluence.py를 bash로 실행.

---

## Phase 5: 완료

로그 업데이트 후 배너 출력:

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
 주간보고 완료
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
 파일:  _reports/weekly_2025-03.md
 수집:  {N}건 / 프로젝트: {P}개 / TODO: {T}건
 로그:  _logs/pipeline_{ts}.json
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
 1. 메인 메뉴로
 2. 종료
선택:
```

이전 보고서 비교 결과가 있으면:
```
 지난 주 대비: 상태 변경 {a}건 / 해소 TODO {b}건
```

---

## MCP 인증 오류

Phase 1 또는 4에서 401/403 감지 시:

```
MCP 인증 오류.

 1. 재인증 후 재시도
 2. 취소
선택:
```
