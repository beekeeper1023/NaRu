---
name: cache-manager
description: "로컬 _cache/ 디렉토리의 파일 생성·읽기·업데이트·체크포인트 관리를 담당하는 스킬. sync-worker와 doc-collector 에이전트가 캐시 파일을 다룰 때 반드시 이 스킬을 참조한다. 파일 경로 규칙, 구조, 체크포인트 포맷을 정의한다."
---

# Cache Manager — 캐시 파일 관리 스킬

## 디렉토리 구조

```
_cache/
├── registry.json                    ← 등록된 스페이스 목록
├── {SPACE}_index.json               ← 스페이스 인덱스 (제목 + 1줄 요약 + URL)
└── {SPACE}/
    ├── .sync_progress.json          ← 전체 동기화 진행률
    ├── .sync_worker_{id}.json       ← 워커별 체크포인트
    └── page_{id}.json               ← 페이지 본문 (정제된 마크다운)
```

## registry.json 구조

```json
{
  "spaces": [
    {
      "key": "DEVWIKI",
      "name": "개발 위키",
      "last_sync": "ISO-8601",
      "total_pages": 150,
      "status": "synced"
    }
  ]
}
```

status: `synced` / `syncing` / `partial` / `error`

## {SPACE}_index.json 구조

```json
{
  "space": "DEVWIKI",
  "built_at": "ISO-8601",
  "pages": [
    {
      "id": "12345",
      "title": "인증 시스템 설계",
      "summary": "JWT 기반 인증을 OAuth 2.0으로 전환하는 설계 문서.",
      "url": "https://...",
      "updated_at": "ISO-8601",
      "created_at": "ISO-8601",
      "author": "홍길동",
      "tags": []
    }
  ]
}
```

인덱스는 항상 메모리에 올려두는 Tier 1 캐시다. (~3,000 tokens)

## page_{id}.json 구조

```json
{
  "page_id": "12345",
  "title": "인증 시스템 설계",
  "url": "https://...",
  "space": "DEVWIKI",
  "author": "홍길동",
  "created_at": "ISO-8601",
  "updated_at": "ISO-8601",
  "tags": [],
  "status": "current",
  "content": "정제된 마크다운 본문 전문"
}
```

페이지 본문은 필요 시 로드하는 Tier 2 캐시다. (~6,000 tokens/page)

## 체크포인트 파일 구조

워커별: `_cache/{SPACE}/.sync_worker_{id}.json`

```json
{
  "worker_id": "worker_1",
  "space": "DEVWIKI",
  "assigned_pages": ["12345", "12346", "12347"],
  "completed": ["12345"],
  "failed": [],
  "last_updated": "ISO-8601"
}
```

**페이지 1개 완료 즉시 기록**한다. 배치 완료를 기다리지 않는다.
워커별 전용 파일을 사용하므로 경쟁 조건(race condition)이 없다.

## 파일 쓰기 원칙
- 항상 임시 파일에 먼저 쓰고 원자적으로 교체한다: `page_{id}.json.tmp` → `page_{id}.json`
- JSON 형식 검증 후 저장한다
- 저장 실패 시 1회 재시도
