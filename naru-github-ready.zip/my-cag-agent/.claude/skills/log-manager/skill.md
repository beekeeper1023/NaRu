---
name: log-manager
description: "파이프라인 실행 로그를 _logs/ 디렉토리에 구조화 JSON으로 기록하는 스킬. 동기화·주간보고·컴파일 모든 작업에 적용. report-orchestrator, space-manager가 작업 시작·종료 시 반드시 이 스킬의 형식으로 로그를 기록한다."
---

# Log Manager — 구조화 로그 스킬 (v9)

## 로그 저장 경로

```
_logs/
├── weekly_{YYYYMMDD_HHMMSS}.json    ← 주간보고 파이프라인
├── sync_{SPACE}_{YYYYMMDD_HHMMSS}.json ← 동기화
└── compile_{YYYYMMDD_HHMMSS}.json   ← 컴파일
```

## 주간보고 로그 스키마

```json
{
  "type": "weekly-report",
  "version": "v9",
  "started_at": "ISO-8601",
  "ended_at": "ISO-8601",
  "success": true,
  "params": {
    "period": {"start": "YYYY-MM-DD", "end": "YYYY-MM-DD"},
    "spaces": ["DEVWIKI"],
    "publish": false,
    "dry_run": false,
    "yes_mode": false
  },
  "phases": {
    "collection": {
      "started_at": "ISO-8601",
      "ended_at": "ISO-8601",
      "success": true,
      "total_matched": 12,
      "new": 2,
      "updated": 10,
      "undated": 0,
      "truncated": 3,
      "unmapped": 1,
      "load_failed": 0,
      "auth_error": false
    },
    "analysis": {
      "started_at": "ISO-8601",
      "ended_at": "ISO-8601",
      "success": true,
      "projects_found": 3,
      "todos_found": 5,
      "has_previous_report": true,
      "diff_applied": true
    },
    "writing": {
      "started_at": "ISO-8601",
      "ended_at": "ISO-8601",
      "success": true,
      "output_path": "_reports/weekly_2025-03.md"
    },
    "publish": {
      "started_at": null,
      "ended_at": null,
      "success": false,
      "skipped": true,
      "reason": "publish: false"
    }
  },
  "errors": [],
  "warnings": []
}
```

## 동기화 로그 스키마

```json
{
  "type": "sync",
  "version": "v9",
  "started_at": "ISO-8601",
  "ended_at": "ISO-8601",
  "success": true,
  "space": "DEVWIKI",
  "mode": "incremental",
  "total_pages": 150,
  "synced": 12,
  "failed": 0,
  "auth_error": false,
  "errors": []
}
```

## 기록 시점

| 시점 | 기록 내용 |
|---|---|
| 파이프라인 시작 | started_at, params |
| 각 Phase 시작 | phase.{name}.started_at |
| 각 Phase 완료 | phase.{name}.ended_at, success, 결과 수치 |
| 에러 발생 | errors 배열에 추가 |
| 파이프라인 종료 | ended_at, success |

## 로그 조회 방법

```
최근 주간보고 로그 확인
_logs/ 에서 weekly_* 파일 중 가장 최신 파일을 읽는다.

특정 날짜 로그 확인
_logs/weekly_{YYYYMMDD}* 패턴으로 탐색.

오류가 있었던 실행만 확인
success: false 인 파일 필터.
```

## 보존 정책

로그 파일은 삭제하지 않는다. 90일 이상 된 파일이 쌓이면 사용자에게 정리 여부를 물어본다.
