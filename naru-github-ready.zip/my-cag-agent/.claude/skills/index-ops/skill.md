---
name: index-ops
description: "동기화 완료 후 {SPACE}_index.json을 빌드하고 1줄 요약을 생성하는 스킬. v9: 200페이지 초과 시 인덱스 자동 분할 규칙 추가. space-manager 에이전트가 전체 동기화 완료 후 호출한다."
---

# Index Ops — 인덱스 빌드 + 요약 생성 스킬 (v9)

## 인덱스 파일 구조

### 300페이지 이하 (분할 없음)

```
_cache/
└── {SPACE}_index.json   ← 단일 파일
```

### 200페이지 초과 (v9 — 자동 분할)

```
_cache/
├── {SPACE}_index_meta.json   ← 청크 정보 (항상 로드)
├── {SPACE}_index_01.json     ← 청크 1 (최신 200개)
├── {SPACE}_index_02.json     ← 청크 2 (다음 200개)
└── {SPACE}_index_03.json     ← 청크 3 (나머지)
```

## 인덱스 메타 파일 구조

```json
{
  "space": "DEVWIKI",
  "built_at": "ISO-8601",
  "total_pages": 450,
  "chunk_size": 200,
  "chunk_count": 3,
  "chunks": [
    {
      "file": "_cache/DEVWIKI_index_01.json",
      "page_count": 200,
      "date_range": {"newest": "ISO-8601", "oldest": "ISO-8601"}
    },
    {
      "file": "_cache/DEVWIKI_index_02.json",
      "page_count": 200,
      "date_range": {}
    },
    {
      "file": "_cache/DEVWIKI_index_03.json",
      "page_count": 50,
      "date_range": {}
    }
  ]
}
```

## 분할 규칙

분할 임계값: **200페이지**
분할 기준: `updated_at` 내림차순 (최신 페이지가 청크 01에)
청크 크기: 200페이지 고정

분할이 필요한 이유:
인덱스 전체가 컨텍스트에 올라가기 때문에 크기를 제어해야 한다.
200페이지 × 30자 요약 ≈ 6,000자 ≈ ~2,000 tokens. 적정 범위.

## 빌드 순서

1. _cache/{SPACE}/ 디렉토리의 page_{id}.json 파일 수 확인
2. 200페이지 이하: 단일 {SPACE}_index.json 빌드
3. 200페이지 초과:
   a. updated_at 내림차순으로 정렬
   b. 200개씩 청크 분할
   c. 각 {SPACE}_index_0N.json 빌드
   d. {SPACE}_index_meta.json 빌드
4. registry.json 업데이트 (last_sync, total_pages, split: true/false)

## 1줄 요약 생성 규칙

본문 첫 500자에서 핵심 내용을 1문장(30자 이내)으로 추출.
"이 문서는..." 서론 표현 제거.
추출 불가 시 페이지 제목을 요약으로 사용.

## 증분 업데이트

전체 재빌드 없이 변경된 페이지 항목만 교체한다.
청크 분할된 경우:
- 변경 페이지가 속한 청크 파일만 수정
- _index_meta.json의 date_range 업데이트
- 새 페이지가 추가되어 청크 크기 초과 시 재분할

## cag-query에 인덱스 로드 안내

분할된 인덱스를 사용하는 에이전트를 위한 로드 순서:
1. {SPACE}_index_meta.json 확인 (존재하면 분할됨)
2. 질의 키워드와 날짜 범위를 보고 관련 청크만 선택 로드
3. 관련 청크를 모두 로드해도 ~6,000 tokens × N개 청크 이내
