---
name: doc-filter
description: "NaRu의 _cache/에서 기간·스페이스·규칙에 맞는 문서를 필터링하여 collected_docs.json을 생성하는 스킬. v9: settings.json의 projectMapping 적용 규칙 추가. doc-collector LLM 에이전트가 반드시 이 스킬을 참조한다."
---

# Doc Filter — 캐시 기반 문서 수집 스킬 (v9)

## 캐시 탐색 순서

1. settings.json → projectMapping 읽기 (v9)
2. _cache/registry.json → 등록 스페이스 확인
3. _cache/{SPACE}_index.json → 날짜 필터링 (인덱스에서 먼저)
4. _cache/{SPACE}/page_{id}.json → 본문 로드 (필터 통과한 것만)

## projectMapping 적용 규칙 (v9)

settings.json의 projectMapping 객체를 읽어 project_name 결정에 사용한다.

적용 우선순위:
1. page_data.project_name 필드 있으면 그대로
2. projectMapping 키워드가 제목에 포함 → 매핑 값 적용
3. projectMapping 키워드가 태그에 포함 → 매핑 값 적용
4. projectMapping 키워드가 본문 앞 200자에 포함 → 매핑 값 적용
5. 태그 project:X 패턴 → X 사용
6. 제목 [X] 앞 괄호 패턴 → X 사용
7. 문맥 추론 가능 → 추론 값
8. 불가 → "미분류"

키워드 탐색: 대소문자·공백 정규화 후 부분 일치 허용.
여러 키워드 매칭 시 제목에서 먼저 발견된 것 우선.
meta에 project_mapping_applied: true, unmapped_count: N 기록.

## 날짜 필터

- updated_at 기간 내 → 수집
- updated_at 없고 created_at 기간 내 → 수집
- 두 날짜 모두 기간 외 → 제외
- 두 날짜 모두 없음 → 수집 + undated: true

change_type: created_at 기간 내 → "new" / updated_at 기간 내 → "updated" / 날짜 없음 → "undated"

## 중복 판정

1. doc_id 동일
2. url + title 동일
3. 제목 유사 + updated_at 1분 이내 → ambiguous_duplicates 기록, 양쪽 포함

## 토큰 상한

- 문서 단위 본문: 1,500자 (초과 시 [이하 생략] + content_truncated: true)
- LLM 분석 배치: 30건 (documents_for_analysis)
- 전체는 documents 배열에 보존

## doc_type 추론

회의록/미팅 → 회의록 | 기획/PRD → 기획문서 | 가이드/매뉴얼 → 가이드
API/스펙/설계 → 기술문서 | 릴리즈/배포 → 릴리즈노트 | 회고 → 회고 | 그 외 → 미분류

## 부분 실패 처리

스페이스 인덱스 없음 → skipped_spaces 기록, 계속
page JSON 로드 실패  → load_failed 기록, 계속
registry.json 없음   → 즉시 실패
수집 0건             → 빈 배열 파일 생성 (중단 금지)
MCP 인증 오류        → 즉시 중단 + 재인증 안내 출력
