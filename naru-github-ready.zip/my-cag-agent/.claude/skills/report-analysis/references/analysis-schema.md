# Analysis Schema — analysis_result.json 전체 스키마

## 목차
1. [최상위 구조](#1-최상위-구조)
2. [run_summary](#2-run_summary)
3. [counts_by_project / counts_by_doc_type](#3-집계-필드)
4. [document_summaries](#4-document_summaries)
5. [weekly_highlights](#5-weekly_highlights)
6. [project_status](#6-project_status)
7. [todo_items](#7-todo_items)
8. [excluded_documents_detail](#8-excluded_documents_detail)
9. [risks_or_conflicts](#9-risks_or_conflicts)
10. [data_quality](#10-data_quality)

---

## 1. 최상위 구조

```json
{
  "page_title": "주간보고 YYYY W{WW}",
  "page_labels": ["weekly-report", "YYYY"],
  "period": {
    "start": "YYYY-MM-DD",
    "end": "YYYY-MM-DD"
  },
  "run_summary": { },
  "counts_by_project": [ ],
  "counts_by_doc_type": [ ],
  "document_summaries": [ ],
  "weekly_highlights": [ ],
  "project_status": [ ],
  "todo_items": [ ],
  "excluded_documents_detail": [ ],
  "risks_or_conflicts": [ ],
  "data_quality": { }
}
```

---

## 2. run_summary

```json
{
  "total_collected": 12,
  "valid_documents": 10,
  "duplicate_documents": 1,
  "excluded_documents": 1,
  "new_documents": 3,
  "updated_documents": 7,
  "undated_documents": 0
}
```

| 필드 | 설명 |
|---|---|
| total_collected | collected_docs.json의 documents 배열 크기 |
| valid_documents | 중복·제외 제거 후 실제 분석 대상 |
| duplicate_documents | 중복 판정 건수 |
| excluded_documents | 분석 규칙으로 제외된 건수 |
| new_documents | created_at이 보고 기간 내 |
| updated_documents | updated_at이 기간 내, created_at은 기간 외 |
| undated_documents | 날짜 정보 없어 판정 불가 |

---

## 3. 집계 필드

```json
"counts_by_project": [
  { "project_name": "프로젝트A", "document_count": 5 },
  { "project_name": "미분류",    "document_count": 2 }
],
"counts_by_doc_type": [
  { "doc_type": "기획문서",  "document_count": 3 },
  { "doc_type": "회의록",    "document_count": 4 },
  { "doc_type": "기술문서",  "document_count": 2 },
  { "doc_type": "미분류",    "document_count": 1 }
]
```

집계 시 valid_documents 기준으로 카운팅한다 (중복·제외 제거 후).

---

## 4. document_summaries

```json
[
  {
    "doc_id": "page_12345",
    "title": "인증 시스템 설계 v2",
    "project_name": "프로젝트A",
    "doc_type": "기술문서",
    "summary": "JWT 기반 인증을 OAuth 2.0으로 전환하는 설계 문서. 토큰 갱신 방식과 세션 관리 정책이 변경되며, 기존 클라이언트 호환성 유지를 위한 마이그레이션 가이드를 포함한다.",
    "source_url": "https://..."
  }
]
```

**summary 작성 기준**: 2~4문장 또는 3개 이하 핵심 bullet. 경영진도 맥락 파악이 가능한 수준. 기술 세부사항보다 변경 이유·영향 범위 중심으로 작성.

---

## 5. weekly_highlights

보고 기간 전체를 관통하는 핵심 변화·결정·리스크를 3~5개 문장으로 정리.
개별 문서 요약이 아닌 전체를 보는 시각으로 작성한다.

```json
"weekly_highlights": [
  "인증 시스템이 OAuth 2.0으로 전환 결정됨. 다음 달 마이그레이션 예정.",
  "배포 자동화 파이프라인 검증 완료. 운영 환경 적용 단계 진입.",
  "결제 모듈 외부 API 장애로 3일 지연. 대체 방안 검토 중."
]
```

---

## 6. project_status

```json
[
  {
    "project_name": "프로젝트A",
    "status": "주의 필요",
    "progress_percent": null,
    "stage": "개발",
    "confidence": "medium",
    "summary": "인증 시스템 전환 작업 진행 중. 설계는 완료되었으나 구현 일정이 다소 지연.",
    "key_updates": [
      "OAuth 2.0 설계 문서 승인 완료",
      "구현 담당자 배정 완료"
    ],
    "risks": [
      "기존 클라이언트 호환성 검증 일정 미확정"
    ],
    "blockers": [],
    "next_actions": [
      "클라이언트 호환성 테스트 계획 수립",
      "마이그레이션 일정 확정"
    ],
    "source_documents": ["page_12345", "page_12346"]
  }
]
```

**필드별 규칙:**

| 필드 | 규칙 |
|---|---|
| progress_percent | 문서에 숫자 명시 시만 사용. 없으면 null |
| stage | 계획/설계/개발/검증/배포·운영/완료/미분류 중 하나 |
| confidence | high/medium/low. 정보 희박 시 low |
| blockers | 명시된 blocker만. 추론 금지 |
| next_actions | 문서에서 드러난 다음 액션만. 일반 권고 추가 금지 |
| source_documents | 이 분석의 근거가 된 doc_id 목록 |

---

## 7. todo_items

```json
[
  {
    "project_name": "프로젝트A",
    "task": "클라이언트 호환성 테스트 계획을 수립한다.",
    "reason": "마이그레이션 일정이 확정되지 않아 일정 지연 위험",
    "priority": "High",
    "owner": null,
    "due_date": null,
    "blocker": null,
    "source_documents": ["page_12345"]
  }
]
```

**task 작성 원칙**: 실행 가능한 명령형 문장. "~를 확인한다", "~를 수립한다" 형태.
**owner, due_date**: 문서에 없으면 반드시 null. 임의 생성 금지.
**priority**: High/Medium/Low (스킬 본문의 기준 참조).

---

## 8. excluded_documents_detail

제외된 문서의 사유 기록.

```json
[
  {
    "doc_id": "page_99999",
    "title": "테스트 페이지",
    "reason": "제목에 '테스트', '임시' 포함 — 제외 규칙 적용"
  }
]
```

---

## 9. risks_or_conflicts

문서 간 충돌 또는 전체 리스크 기록.

```json
[
  {
    "project_name": "프로젝트B",
    "issue": "page_11111(2025-01-13)과 page_11112(2025-01-16)에서 배포 일정이 서로 다르게 명시됨",
    "resolution_hint": "더 최신 문서(page_11112)를 기준으로 분석했으나 확인 필요",
    "source_documents": ["page_11111", "page_11112"]
  }
]
```

---

## 10. data_quality

```json
{
  "missing_project_mapping": ["page_77777", "page_88888"],
  "missing_dates": ["page_55555"],
  "ambiguous_duplicates": ["page_33333 / page_33334 — 제목 유사, 시간 차 2분"],
  "notes": ["Phase 2 분석 중 page_44444 로드 실패로 건너뜀"]
}
```
