---
name: report-analysis
description: "documents_for_analysis(최대 30건)를 분석하여 요약·프로젝트 현황·TODO를 도출하는 스킬. v9: 이전 보고서 diff 분석 규칙 추가. meta 카운팅 위임(재계산 금지). report-analyst 에이전트가 참조한다."
---

# Report Analysis — 문서 분석 스킬 (v9)

## v9 핵심 변경

이전 보고서 비교(weekly_diff) 섹션이 추가됐다.
나머지 규칙은 v8과 동일.

---

## 분석 단계 (4+1)

### 1. 집계 (meta에서 그대로)

meta 필드 → run_summary 매핑:
- total_matched → total_collected
- new_count → new_documents
- updated_count → updated_documents
- undated_count → undated_documents

중복·제외는 doc-collector가 처리했으므로 0으로 기입.
data_quality.notes에 "중복 제거는 수집 단계에서 처리됨" 명시.

needs_batch: true이면 분석 결과 상단에:
분석 범위: 전체 {total_matched}건 중 최신 {docs_for_analysis_count}건.

### 2. 문서 요약

각 문서 2~4문장. change_type 참고하여 신규/업데이트 구분.
content_truncated: true 문서는 "(본문 일부 생략)" 표기.

### 3. 프로젝트 현황

project_name 필드 그대로 사용 (doc-collector가 projectMapping 적용 완료).
"미분류" 그룹은 문서 내용으로 재추론 시도.

상태 분류: 정상 진행 / 주의 필요 / 지연·리스크 / 완료 / 정보 부족
단계: 계획 / 설계 / 개발 / 검증 / 배포·운영 / 완료 / 미분류
진행률: 숫자 명시 시만. 없으면 null + stage + confidence(high/medium/low).

### 4. TODO 도출

문서에서 직접 드러난 액션만. 추론·일반 권고 금지.
우선순위: High(blocker/마감임박) / Medium(이번~다음 주) / Low(참고성).
owner, due_date 없으면 null.

### 5. 이전 보고서 비교 (v9 — previous 있을 때만)

이전 보고서에서 추출할 항목:
- 프로젝트별 상태 목록
- TODO 목록 (task 텍스트)
- 보고 기간 및 total_collected

비교 결과 → weekly_diff 필드:
```json
{
  "has_previous": true,
  "new_projects": [],
  "status_changes": [
    {"project": "A", "from": "주의 필요", "to": "정상 진행"}
  ],
  "resolved_todos": [],
  "persisted_todos": [],
  "collection_change": {"previous": 8, "current": 12, "delta": 4}
}
```

이전 TODO와 현재 TODO 매칭 방법:
- task 텍스트가 80% 이상 유사하면 같은 항목으로 간주
- 현재 문서에서 "완료", "done", "해결" 언급이 있으면 resolved_todos로 분류
- 현재에도 유사 항목이 있으면 persisted_todos로 분류

---

## 핵심 원칙

근거 중심: 입력 내용만 사용. 없는 수치·담당자·일정 생성 금지.
카운팅 위임: meta 값 그대로. 직접 계산 금지.
충돌 보존: 상충 정보는 risks_or_conflicts에 기록. 삭제 금지.

---

## 출력 스키마

기존 스키마에 weekly_diff 필드 추가 (references/analysis-schema.md 참조).
