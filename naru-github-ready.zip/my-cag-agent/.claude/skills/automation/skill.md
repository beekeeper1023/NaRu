---
name: automation
description: "배치 자동화 설정 스킬. 'cron 설정해줘', '자동 실행 설정', '매주 자동으로 주간보고', 'launchd 설정' 요청 시 이 스킬을 참조. scripts/setup_schedule.sh 실행 안내와 --yes 플래그(자동화 모드) 동작 규칙을 정의한다."
---

# Automation — 배치 자동화 스킬 (v9)

## 자동화 구성 요소

```
scripts/
├── run_weekly_report.sh   ← cron/launchd 진입점
└── setup_schedule.sh      ← 스케줄 등록 헬퍼
```

## 설정 방법

### 대화형 설정 (권장)

```
자동 실행 설정해줘
매주 자동으로 주간보고 만들어줘
cron 설정해줘
```

에이전트가 scripts/setup_schedule.sh 실행을 안내한다:

```bash
bash scripts/setup_schedule.sh
```

### 수동 설정

```bash
# launchd (macOS)
bash scripts/setup_schedule.sh
# → 대화형으로 요일·시간·스페이스 선택

# 직접 cron 추가 (매주 월요일 09:00, DEVWIKI)
(crontab -l 2>/dev/null; echo "0 9 * * 1 cd ~/desktop/my-naru && bash scripts/run_weekly_report.sh --space DEVWIKI") | crontab -

# 스케줄 확인
crontab -l
launchctl list | grep naru
```

### run_weekly_report.sh 직접 실행

```bash
# 전체 스페이스, 로컬 저장
bash scripts/run_weekly_report.sh

# 특정 스페이스
bash scripts/run_weekly_report.sh --space DEVWIKI

# 특정 스페이스 + Confluence 게시
bash scripts/run_weekly_report.sh --space DEVWIKI --publish
```

## --yes 플래그 동작 규칙

자동화 환경에서는 선택 단계를 사람이 응답할 수 없다.
명령에 `--yes`가 포함되거나 `run_weekly_report.sh`에서 실행되면:

| 상황 | --yes 없음 | --yes 있음 |
|---|---|---|
| 기간·스페이스·게시 선택 | 대화형 선택 | settings.json 기본값 사용 |
| 실행 전 확인 (Y/N) | 질문 | 자동 Y |
| 수집 0건 | "계속할까요? Y/N" | 자동 Y (빈 보고서 생성) |
| 파일 충돌 | "_v2 추가할까요? Y/N" | 자동 _v2 추가 |
| MCP 인증 오류 | 안내 출력 후 대기 | 안내 출력 + 스크립트 종료 코드 1 |

--yes 모드에서 기본값 적용 순서:
1. 명령에 명시된 파라미터 우선
2. settings.json의 weeklyReport 기본값
3. 하드코딩 기본값 (period: this_week, publish: false)

## 자동화 로그

run_weekly_report.sh 실행 시:
- 터미널 출력을 `_logs/cron_{YYYYMMDD_HHMMSS}.log`에 동시 기록
- 에이전트가 생성하는 `_logs/weekly_{ts}.json`과 별도 보관
- 종료 코드 0: 성공, 1: 실패

## 스케줄 제거

```bash
# launchd 제거
launchctl unload ~/Library/LaunchAgents/com.naru.weekly-report.plist
rm ~/Library/LaunchAgents/com.naru.weekly-report.plist

# cron 제거
crontab -e   # 해당 줄 삭제
```
