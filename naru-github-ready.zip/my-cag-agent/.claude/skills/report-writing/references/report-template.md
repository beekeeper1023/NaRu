# Report Template — 주간보고 마크다운 템플릿

이 파일은 `report-writer` 에이전트가 보고서를 작성할 때 정확히 따라야 하는 마크다운 구조다.
섹션 순서·헤딩 수준·표 구조는 고정이다. 괄호 안의 지시는 실제 보고서에 포함하지 않는다.

---

```markdown
# 주간보고 {YYYY} W{WW}

> 보고 기간: {YYYY-MM-DD} ~ {YYYY-MM-DD} | 대상: {스페이스 목록} | 생성: {ISO-8601}

---

## 1. 보고 개요

- **보고 기간**: {start} ~ {end}
- **대상 범위**: {스페이스 목록}
- **수집 결과**: 총 {total_collected}건 수집, 유효 {valid_documents}건 분석
  (중복 {duplicate_documents}건 제외, 신규 {new_documents}건 / 업데이트 {updated_documents}건)

---

## 2. 이번 주 핵심 요약

- {weekly_highlights[0]}
- {weekly_highlights[1]}
- {weekly_highlights[2]}
(highlights가 5개 이하라면 모두 포함)

---

## 3. 문서 등록 현황

### 3.1 전체 집계

| 항목 | 건수 |
|---|---:|
| 총 수집 문서 | {total_collected} |
| 유효 문서 | {valid_documents} |
| 중복 문서 | {duplicate_documents} |
| 제외 문서 | {excluded_documents} |
| 신규 등록 | {new_documents} |
| 업데이트 | {updated_documents} |
| 날짜 미상 | {undated_documents} |

### 3.2 프로젝트별 집계

| 프로젝트 | 문서 수 | 주요 내용 |
|---|---:|---|
| {project_name} | {document_count} | {해당 프로젝트 핵심 업데이트 1줄} |
| ... | | |

### 3.3 문서 유형별 집계

| 문서 유형 | 건수 |
|---|---:|
| {doc_type} | {document_count} |
| ... | |

---

## 4. 프로젝트별 현황

(project_status 배열의 각 항목을 아래 구조로 반복)

### {project_name}

- **상태**: {status}
- **진행률**: {progress_percent}% (progress_percent가 null이면 → 현재 단계: {stage} / 신뢰도: {confidence})
- **현재 단계**: {stage}
- **핵심 업데이트**:
  - {key_updates[0]}
  - {key_updates[1]}
- **리스크 / 이슈**: (없으면 이 항목 생략)
  - {risks[0]}
- **Blocker**: (없으면 이 항목 생략)
  - {blockers[0]}
- **다음 액션**: (없으면 "없음"으로 명시)
  - {next_actions[0]}
- **출처**: {source_documents 목록, 링크 포함 시 [제목](url) 형식}

---

## 5. 해야 할 일

(High → Medium → Low 순 정렬. blocker 있는 행은 **굵게**)

| 프로젝트 | 할 일 | 우선순위 | 담당자 | 기한 | Blocker | 출처 |
|---|---|---|---|---|---|---|
| {project_name} | {task} | {priority} | {owner 또는 확인 필요} | {due_date 또는 확인 필요} | {blocker 또는 -} | {source_documents} |
| ... | | | | | | |

---

## 6. 리스크 및 확인 필요 사항

(risks_or_conflicts + data_quality 기반)

### 6.1 문서 간 충돌

(risks_or_conflicts 있을 경우)
- **{project_name}**: {issue} — {resolution_hint}
  - 출처: {source_documents}

(없을 경우)
- 해당 없음

### 6.2 데이터 품질 이슈

(data_quality 기반)
- 프로젝트 미분류 문서: {missing_project_mapping 목록}
- 날짜 정보 없는 문서: {missing_dates 목록}
- 중복 의심 문서: {ambiguous_duplicates 목록}
- 기타: {notes 목록}

(모두 없을 경우)
- 해당 없음

---

## 7. 문서별 요약

(document_summaries 배열 기반. 20건 이상이면 프로젝트별로 묶어 표시)

### {title}

- **프로젝트**: {project_name}
- **문서 유형**: {doc_type}
- **요약**: {summary}
- **링크**: {source_url}

(반복)
```

---

## 폴백 배너 (Phase 2 실패 시 보고서 상단에 추가)

```markdown
> **경고**: 분석 단계(Phase 2)가 완료되지 않아 집계 및 기본 목록만 포함됩니다.
> 프로젝트 현황(섹션 4), 해야 할 일(섹션 5), 리스크(섹션 6)는 수동 확인이 필요합니다.
```
