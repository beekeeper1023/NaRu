---
name: confluence-publish
description: "Confluence 업로드 스킬. 'Confluence에 올려줘', '업로드해줘', '게시해줘' 요청 시 참조. v9: MCP 불사용. scripts/upload_to_confluence.py를 Bash로 실행. 크기 기준 자동 분기(단일/분할), 재시도, 로그 기록을 스크립트가 처리한다."
---

# Confluence Publish — 업로드 스킬 (v9)

## 전체 흐름

```
마크다운 파일
    │
    ▼
upload_to_confluence.py  (Python, 표준 라이브러리만 사용)
    │
    ├── 크기 < 50KB → 단일 페이지 업로드
    └── 크기 ≥ 50KB → ## 헤딩 기준 분할
                          ├── 상위 페이지 (요약 + 목차)
                          └── 하위 페이지 × N (섹션별)
```

---

## 스크립트 실행 방법

```bash
# 기본 (최신 보고서 자동 탐색)
python3 scripts/upload_to_confluence.py

# 파일·스페이스 지정
python3 scripts/upload_to_confluence.py \
  --file _reports/weekly_2025-03.md \
  --space DEVWIKI \
  --title "주간보고 2025 W03" \
  --parent "주간보고 아카이브"

# 드라이런 (변환만, 업로드 안 함)
python3 scripts/upload_to_confluence.py --dry-run

# 보고서 목록 확인
python3 scripts/upload_to_confluence.py --list
```

---

## 사전 설정 (settings.json)

업로드에 필요한 필드:

| 필드 | 위치 | 설명 |
|---|---|---|
| Confluence 도메인 | `confluence.domain` | `https://company.atlassian.net` |
| 이메일 | `user.email` | Atlassian 계정 이메일 |
| API 토큰 | `apiKeys.atlassian` | id.atlassian.com에서 발급 |
| 기본 스페이스 | `weeklyReport.defaultSpaces[0]` | 업로드 대상 스페이스 |
| 상위 페이지 | `confluence.reportParentPage` | 선택사항 |

---

## 크기 기준 분기

| 파일 크기 | 전략 | 생성 페이지 |
|---|---|---|
| < 50 KB | 단일 페이지 | 1개 |
| ≥ 50 KB | 분할 | 상위 1개 + ## 섹션 수만큼 하위 |

분할 기준: `##` (H2) 헤딩. 주간보고의 경우 섹션 7개 → 상위 1 + 하위 7 = 8페이지.

---

## 인증 방식

MCP를 사용하지 않는다. Confluence REST API 직접 호출:

```
Authorization: Basic base64(user.email:apiKeys.atlassian)
Content-Type: application/json
```

API 엔드포인트:
- 페이지 탐색: `GET /wiki/rest/api/content?title=...&spaceKey=...`
- 페이지 생성: `POST /wiki/rest/api/content`
- 페이지 업데이트: `PUT /wiki/rest/api/content/{id}`

---

## 재시도 정책

- 최대 3회 재시도
- 지수 백오프: 2초 → 4초 → 8초
- 401/403: 재시도 없이 즉시 인증 오류 안내
- 타임아웃: 60초/요청 (MCP의 30초보다 완화)

---

## 로그

업로드 완료 시 `_logs/upload_{YYYYMMDD_HHMMSS}.json` 자동 생성:

```json
{
  "type": "upload",
  "file": "_reports/weekly_2025-03.md",
  "file_size_kb": 38.4,
  "space": "DEVWIKI",
  "title": "주간보고 2025-03",
  "strategy": "single",
  "pages": [
    {"action": "created", "url": "https://..."}
  ]
}
```

---

## 마크다운 → Storage Format 변환 지원 범위

스크립트 내장 변환기가 처리:

| 마크다운 | 변환 결과 |
|---|---|
| `# 제목` ~ `###### 제목` | h1 ~ h6 |
| `**굵게**`, `__굵게__` | strong |
| `*이탤릭*`, `_이탤릭_` | em |
| `~~취소선~~` | del |
| `` `인라인 코드` `` | code |
| 코드 블록 (` ``` `) | Confluence code 매크로 |
| `[텍스트](url)` | a href |
| `\| 표 \|` | Confluence table |
| `- 항목`, `* 항목` | ul/li |
| `1. 항목` | ol/li |
| `> 인용` | blockquote |
| `---` | hr |
