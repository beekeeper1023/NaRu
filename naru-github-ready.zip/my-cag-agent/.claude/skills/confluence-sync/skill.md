---
name: confluence-sync
description: "Atlassian Rovo MCP를 통해 Confluence 페이지를 fetch하고 HTML을 마크다운으로 정제하는 스킬. v9: MCP 인증 오류 감지·재인증 안내·레이트 리밋 처리 강화. sync-worker와 doc-collector 에이전트가 참조한다."
---

# Confluence Sync — Rovo MCP 연동 스킬 (v9)

## MCP 연동

Atlassian Rovo MCP (https://mcp.atlassian.com/v1/mcp) 사용.
settings.json의 MCP 설정으로 자동 인증된다.

## MCP 인증 오류 처리 (v9)

### 오류 감지 조건

아래 중 하나라도 해당하면 auth_error로 분류한다:
- API 응답 HTTP 401 또는 403
- 오류 메시지에 포함: "authentication", "unauthorized", "token expired",
  "invalid credentials", "access denied", "session expired"
- MCP 연결 자체가 끊겨 도구 호출 불가

### auth_error 대응 규칙

1. 현재 작업을 즉시 중단한다 (재시도 금지 — 재시도해도 동일 오류 반복)
2. 아래 안내를 출력한다:

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
 MCP 인증 오류 — 재인증 필요
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
 Atlassian Rovo MCP 세션이 만료되었습니다.

 아래 명령어를 터미널에서 실행하세요:

   claude mcp remove atlassian-rovo
   claude mcp add atlassian-rovo \
     --transport sse \
     https://mcp.atlassian.com/v1/mcp

 Atlassian 로그인 팝업이 뜨면 승인 후 다시 시도하세요.
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

3. 동기화 중 발생 시: 체크포인트가 저장되어 있으므로 재인증 후 "재개해줘"로 이어서 가능
4. 주간보고 Phase 1 중 발생 시: Phase 1부터 다시 시작
5. 로그에 auth_error: true 기록

### 일시적 오류 vs 인증 오류 구분

| 오류 종류 | 처리 |
|---|---|
| 네트워크 타임아웃 | 재시도 (최대 3회, 간격 2초) |
| HTTP 429 (레이트 리밋) | Retry-After 대기 후 재시도 |
| HTTP 500/503 | 재시도 (최대 2회) |
| HTTP 401/403 | auth_error → 즉시 중단 |
| 연결 자체 불가 | auth_error로 간주 → 즉시 중단 |

## 페이지 목록 조회

- searchConfluenceUsingCql 도구 사용
- CQL: space = "{SPACE_KEY}" AND type = page ORDER BY lastModified DESC
- 증분 업데이트: lastModified >= "{last_sync_date}" 조건 추가

## 페이지 본문 fetch

- getConfluencePage 도구 사용 (page_id 기준)
- 타임아웃: 30초
- 타임아웃 초과 → 실패 처리 (auth_error 아님)

## HTML → 마크다운 정제

h1~h6 → # | p → 줄바꿈 | ul/li → - | ol/li → 1. | strong → ** | em → *
code → 백틱 | pre → 코드 블록 | a href → [텍스트](url) | table → 마크다운 표
Confluence 매크로 → [매크로명: 내용 생략] | 첨부 이미지 → [이미지: 파일명]
메타 태그·스타일·스크립트 → 전부 제거

## 레이트 리밋 처리

- 연속 요청 간 0.5초 대기
- 429 수신 시 Retry-After 헤더 값만큼 대기 (없으면 5초)
- 최대 3회 재시도 후 실패 → 실패 목록 기록, 계속 진행
